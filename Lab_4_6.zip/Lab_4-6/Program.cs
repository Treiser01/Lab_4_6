﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_4_6
{
    class Program
    {
        static void Main(string[] args)
        {
            double max, min, x, y, F;
            x = 1;
            y = 3;
            max = (x * x + y * y > x - y) ? x - y : x * x + y * y;
            min = (x > y) ? x : y;
            F = (max + x) / (min * min + Math.Pow(y,4));

          Console.WriteLine(F);
          Console.ReadKey();
        }
    }
}
